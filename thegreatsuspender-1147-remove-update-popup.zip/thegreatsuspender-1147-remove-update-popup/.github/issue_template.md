Please complete the following information when submitting a feature request or bug report.
 * Extension version:
 * Browser name & version:
 * Operating system & version:

And please also do a search for your request/bug before create a new one thanks!
